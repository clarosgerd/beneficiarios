CREATE VIEW viewactividad AS
  SELECT
    `benificiaries`.`sector`.`nombre`                   AS `sector`,
    `benificiaries`.`tipoactividad`.`nombre`            AS `tipoactividad`,
    `benificiaries`.`actividad`.`nombreactividad`       AS `nombreactividad`,
    `benificiaries`.`actividad`.`nombrelocal`           AS `nombrelocal`,
    `benificiaries`.`centros`.`nombreinstitucion`       AS `nombreinstitucion`,
    `benificiaries`.`unidadeducativa`.`nombre`          AS `organizador`,
    `benificiaries`.`actividad`.`direccionlocal`        AS `direccionlocal`,
    `benificiaries`.`actividad`.`fecha_inicio`          AS `fecha_inicio`,
    `benificiaries`.`actividad`.`fecha_fin`             AS `fecha_fin`,
    `benificiaries`.`actividad`.`horasprogramadas`      AS `horasprogramadas`,
    concat(`benificiaries`.`persona`.`nombre`, ' ', `benificiaries`.`persona`.`apellidopaterno`, ' ',
           `benificiaries`.`persona`.`apellidomaterno`) AS `facilitador`,
    `benificiaries`.`actividad`.`contenido`             AS `contenido`,
    `benificiaries`.`actividad`.`observaciones`         AS `observaciones`
  FROM (((((`benificiaries`.`actividad`
    JOIN `benificiaries`.`sector` ON ((`benificiaries`.`sector`.`id` = `benificiaries`.`actividad`.`id_sector`))) JOIN
    `benificiaries`.`tipoactividad`
      ON ((`benificiaries`.`tipoactividad`.`id` = `benificiaries`.`actividad`.`id_tipoactividad`))) JOIN
    `benificiaries`.`persona` ON ((`benificiaries`.`persona`.`id` = `benificiaries`.`actividad`.`id_persona`))) JOIN
    `benificiaries`.`centros` ON ((`benificiaries`.`centros`.`id` = `benificiaries`.`actividad`.`id_centro`))) JOIN
    `benificiaries`.`unidadeducativa`
      ON ((`benificiaries`.`unidadeducativa`.`id` = `benificiaries`.`actividad`.`organizador`)));
