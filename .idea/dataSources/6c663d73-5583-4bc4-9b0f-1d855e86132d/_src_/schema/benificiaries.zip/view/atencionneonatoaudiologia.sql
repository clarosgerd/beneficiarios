CREATE VIEW atencionneonatoaudiologia AS
  SELECT
    `benificiaries`.`atencion`.`id`              AS `id1`,
    `benificiaries`.`atencion`.`id_neonato`      AS `id_neonato`,
    `benificiaries`.`atencion`.`id_especialista` AS `id_especialista`,
    `benificiaries`.`atencion`.`id_referencia`   AS `id_referencia`
  FROM `benificiaries`.`atencion`;
