CREATE VIEW viewestudiantesetareo AS
  SELECT
    `benificiaries`.`unidadeducativa`.`nombre`      AS `unidadeducativa`,
    sum((CASE WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 0) AND
                    (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
      THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 1) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 2) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 3) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 4) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 5) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 6) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 7) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 8) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 9) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 10) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 11) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 12) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 13) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 14) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 15) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 16) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 17) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 18) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) >= 19) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         ELSE 0 END))                               AS `0-3F`,
    sum((CASE WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 0) AND
                    (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
      THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 1) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 2) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 3) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 4) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 5) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 6) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 7) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 8) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 9) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 10) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 11) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 12) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 13) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 14) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 15) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 16) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 17) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 18) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) >= 19) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         ELSE 0 END))                               AS `4-6F`,
    sum((CASE WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 0) AND
                    (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
      THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 1) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 2) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 3) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 4) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 5) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 6) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 7) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 8) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 9) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 10) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 11) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 12) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 13) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 14) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 15) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 16) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 17) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 18) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) >= 19) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         ELSE 0 END))                               AS `7-9F`,
    sum((CASE WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 0) AND
                    (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
      THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 1) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 2) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 3) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 4) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 5) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 6) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 7) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 8) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 9) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 10) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 11) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 12) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 13) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 14) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 15) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 16) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 17) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 18) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) >= 19) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         ELSE 0 END))                               AS `10-12F`,
    sum((CASE WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 0) AND
                    (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
      THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 1) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 2) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 3) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 4) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 5) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 6) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 7) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 8) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 9) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 10) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 11) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 12) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 13) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 14) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 15) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 16) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 17) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 18) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) >= 19) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         ELSE 0 END))                               AS `13-15F`,
    sum((CASE WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 0) AND
                    (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
      THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 1) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 2) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 3) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 4) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 5) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 6) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 7) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 8) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 9) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 10) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 11) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 12) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 13) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 14) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 15) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 16) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 17) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 18) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) >= 19) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         ELSE 0 END))                               AS `16-18F`,
    sum((CASE WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 0) AND
                    (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
      THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 1) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 2) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 3) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 4) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 5) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 6) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 7) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 8) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 9) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 10) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 11) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 12) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 13) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 14) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 15) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 16) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 17) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 18) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) >= 19) AND
               (`benificiaries`.`estudiante`.`sexo` = 'FEMENINO'))
           THEN 1
         ELSE 0 END))                               AS `19F`,
    sum((CASE WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 0) AND
                    (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
      THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 1) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 2) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 3) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 4) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 5) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 6) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 7) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 8) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 9) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 10) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 11) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 12) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 13) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 14) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 15) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 16) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 17) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 18) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) >= 19) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         ELSE 0 END))                               AS `0-3M`,
    sum((CASE WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 0) AND
                    (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
      THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 1) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 2) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 3) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 4) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 5) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 6) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 7) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 8) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 9) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 10) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 11) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 12) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 13) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 14) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 15) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 16) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 17) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 18) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) >= 19) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         ELSE 0 END))                               AS `4-6M`,
    sum((CASE WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 0) AND
                    (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
      THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 1) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 2) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 3) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 4) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 5) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 6) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 7) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 8) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 9) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 10) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 11) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 12) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 13) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 14) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 15) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 16) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 17) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 18) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) >= 19) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         ELSE 0 END))                               AS `7-9M`,
    sum((CASE WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 0) AND
                    (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
      THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 1) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 2) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 3) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 4) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 5) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 6) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 7) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 8) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 9) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 10) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 11) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 12) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 13) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 14) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 15) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 16) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 17) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 18) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) >= 19) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         ELSE 0 END))                               AS `10-12M`,
    sum((CASE WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 0) AND
                    (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
      THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 1) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 2) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 3) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 4) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 5) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 6) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 7) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 8) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 9) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 10) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 11) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 12) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 13) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 14) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 15) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 16) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 17) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 18) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) >= 19) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         ELSE 0 END))                               AS `13-15M`,
    sum((CASE WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 0) AND
                    (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
      THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 1) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 2) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 3) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 4) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 5) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 6) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 7) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 8) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 9) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 10) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 11) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 12) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 13) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 14) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 15) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 16) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 17) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 18) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 1
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) >= 19) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         ELSE 0 END))                               AS `16-18M`,
    sum((CASE WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 0) AND
                    (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
      THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 1) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 2) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 3) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 4) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 5) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 6) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 7) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 8) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 9) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 10) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 11) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 12) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 13) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 14) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 15) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 16) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 17) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) = 18) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 0
         WHEN ((timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) >= 19) AND
               (`benificiaries`.`estudiante`.`sexo` = 'MASCULINO'))
           THEN 1
         ELSE 0 END))                               AS `19M`,
    `benificiaries`.`inscripcionestudiante`.`fecha` AS `fecha`
  FROM ((`benificiaries`.`estudiante`
    JOIN `benificiaries`.`unidadeducativa`
      ON ((`benificiaries`.`unidadeducativa`.`id` = `benificiaries`.`estudiante`.`unidadeducativa`))) JOIN
    `benificiaries`.`inscripcionestudiante`
      ON ((`benificiaries`.`inscripcionestudiante`.`id_estudiante` = `benificiaries`.`estudiante`.`id`)))
  GROUP BY `benificiaries`.`unidadeducativa`.`nombre`, `benificiaries`.`inscripcionestudiante`.`fecha`;
