CREATE VIEW viewdocente AS
  SELECT
    `benificiaries`.`departamento`.`nombre`       AS `deoartamento`,
    `benificiaries`.`unidadeducativa`.`nombre`    AS `unidadeducativa`,
    `benificiaries`.`docente`.`nombres`           AS `nombres`,
    `benificiaries`.`docente`.`apellidopaterno`   AS `apellidopaterno`,
    `benificiaries`.`docente`.`apellidomaterno`   AS `apellidomaterno`,
    `benificiaries`.`docente`.`nrodiscapacidad`   AS `nrodiscapacidad`,
    `benificiaries`.`docente`.`ci`                AS `ci`,
    `benificiaries`.`docente`.`fechanacimiento`   AS `fechanacimiento`,
    `benificiaries`.`docente`.`sexo`              AS `sexo`,
    `benificiaries`.`docente`.`celular`           AS `celular`,
    `benificiaries`.`docente`.`materias`          AS `materias`,
    `benificiaries`.`centros`.`nombreinstitucion` AS `nombreinstitucion`,
    `benificiaries`.`discapacidad`.`nombre`       AS `discapacidad`,
    `benificiaries`.`tipodiscapacidad`.`nombre`   AS `tipodiscapacidad`
  FROM (((((`benificiaries`.`docente`
    LEFT JOIN `benificiaries`.`departamento`
      ON ((`benificiaries`.`departamento`.`id` = `benificiaries`.`docente`.`id_departamento`))) LEFT JOIN
    `benificiaries`.`unidadeducativa`
      ON ((`benificiaries`.`unidadeducativa`.`id` = `benificiaries`.`docente`.`unidadeducativa`))) LEFT JOIN
    `benificiaries`.`centros` ON ((`benificiaries`.`centros`.`id` = `benificiaries`.`docente`.`id_centro`))) JOIN
    `benificiaries`.`discapacidad`
      ON ((`benificiaries`.`discapacidad`.`id` = `benificiaries`.`docente`.`discapacidad`))) JOIN
    `benificiaries`.`tipodiscapacidad`
      ON ((`benificiaries`.`tipodiscapacidad`.`id` = `benificiaries`.`docente`.`tipodiscapacidad`)));
