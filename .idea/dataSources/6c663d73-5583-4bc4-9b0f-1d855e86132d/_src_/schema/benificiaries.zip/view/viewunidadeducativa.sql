CREATE VIEW viewunidadeducativa AS
  SELECT
    `benificiaries`.`centros`.`nombreinstitucion`                             AS `centro`,
    `benificiaries`.`unidadeducativa`.`nombre`                                AS `unidadeducativa`,
    `benificiaries`.`unidadeducativa`.`codigo_sie`                            AS `codigo_sie`,
    `benificiaries`.`departamento`.`nombre`                                   AS `departamento`,
    `benificiaries`.`municipio`.`nombre`                                      AS `municipio`,
    `benificiaries`.`provincia`.`nombre`                                      AS `principio`,
    `benificiaries`.`unidadeducativa`.`direccion`                             AS `direccion`,
    `benificiaries`.`unidadeducativa`.`telefono`                              AS `telefono`,
    `benificiaries`.`unidadeducativa`.`email`                                 AS `email`,
    concat(`benificiaries`.`persona`.`nombre`, ' ', `benificiaries`.`persona`.`apellidopaterno`, ' ',
           `benificiaries`.`persona`.`apellidomaterno`)                       AS `director`,
    (SELECT count(`es`.`id`)
     FROM `benificiaries`.`estudiante` `es`
     WHERE (`es`.`unidadeducativa` = `benificiaries`.`unidadeducativa`.`id`)) AS `cantidadalumnos`,
    (SELECT count(`es`.`id`)
     FROM `benificiaries`.`estudiante` `es`
     WHERE ((`es`.`unidadeducativa` = `benificiaries`.`unidadeducativa`.`id`) AND (`es`.`sexo` = 'MASCULINO') AND
            (`es`.`discapacidad` = 1)))                                       AS `cantidadalumnosvaronessi`,
    (SELECT count(`es`.`id`)
     FROM `benificiaries`.`estudiante` `es`
     WHERE ((`es`.`unidadeducativa` = `benificiaries`.`unidadeducativa`.`id`) AND (`es`.`sexo` = 'MASCULINO') AND
            (`es`.`discapacidad` = 2)))                                       AS `cantidadalumnosvaronesno`,
    (SELECT count(`es`.`id`)
     FROM `benificiaries`.`estudiante` `es`
     WHERE ((`es`.`unidadeducativa` = `benificiaries`.`unidadeducativa`.`id`) AND (`es`.`sexo` = 'FEMENINO') AND
            (`es`.`discapacidad` = 1)))                                       AS `cantidadalumnosmujeressi`,
    (SELECT count(`es`.`id`)
     FROM `benificiaries`.`estudiante` `es`
     WHERE ((`es`.`unidadeducativa` = `benificiaries`.`unidadeducativa`.`id`) AND (`es`.`sexo` = 'FEMENINO') AND
            (`es`.`discapacidad` = 2)))                                       AS `cantidadalumnosmujeresno`
  FROM (((((`benificiaries`.`unidadeducativa`
    JOIN `benificiaries`.`centros`
      ON ((`benificiaries`.`centros`.`id` = `benificiaries`.`unidadeducativa`.`id_centro`))) JOIN
    `benificiaries`.`departamento`
      ON ((`benificiaries`.`departamento`.`id` = `benificiaries`.`unidadeducativa`.`departamento`))) JOIN
    `benificiaries`.`provincia`
      ON ((`benificiaries`.`provincia`.`id` = `benificiaries`.`unidadeducativa`.`provincia`))) JOIN
    `benificiaries`.`municipio`
      ON ((`benificiaries`.`municipio`.`id` = `benificiaries`.`unidadeducativa`.`municipio`))) JOIN
    `benificiaries`.`persona` ON ((`benificiaries`.`persona`.`id` = `benificiaries`.`unidadeducativa`.`id_persona`)));
