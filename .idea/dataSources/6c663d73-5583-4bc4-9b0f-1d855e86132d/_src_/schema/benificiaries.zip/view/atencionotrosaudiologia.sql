CREATE VIEW atencionotrosaudiologia AS
  SELECT
    `benificiaries`.`atencion`.`id`              AS `id`,
    `benificiaries`.`atencion`.`id_otros`        AS `id_otros`,
    `benificiaries`.`atencion`.`id_especialista` AS `id_especialista`,
    `benificiaries`.`atencion`.`id_referencia`   AS `id_referencia`
  FROM `benificiaries`.`atencion`;
