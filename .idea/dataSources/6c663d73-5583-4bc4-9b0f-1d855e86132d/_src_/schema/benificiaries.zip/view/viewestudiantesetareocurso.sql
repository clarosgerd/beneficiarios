CREATE VIEW viewestudiantesetareocurso AS
  SELECT
    `benificiaries`.`estudiante`.`id`               AS `id`,
    `benificiaries`.`estudiante`.`nombres`          AS `nombres`,
    `benificiaries`.`estudiante`.`apellidopaterno`  AS `apellidopaterno`,
    `benificiaries`.`estudiante`.`apellidomaterno`  AS `apellidomaterno`,
    `benificiaries`.`estudiante`.`codigorude_es`    AS `codigorude_es`,
    `benificiaries`.`estudiante`.`ci`               AS `ci`,
    `benificiaries`.`curso`.`curso`                 AS `curso`,
    `benificiaries`.`discapacidad`.`nombre`         AS `discapacidad`,
    `benificiaries`.`tipodiscapacidad`.`nombre`     AS `tipodiscapacidad`,
    `benificiaries`.`unidadeducativa`.`nombre`      AS `unidadeducativa`,
    `benificiaries`.`inscripcionestudiante`.`fecha` AS `fecha`
  FROM (((((((((`benificiaries`.`estudiante`
    LEFT JOIN `benificiaries`.`departamento`
      ON ((`benificiaries`.`departamento`.`id` = `benificiaries`.`estudiante`.`departamento`))) LEFT JOIN
    `benificiaries`.`municipio`
      ON ((`benificiaries`.`municipio`.`id` = `benificiaries`.`estudiante`.`municipio`))) LEFT JOIN
    `benificiaries`.`provincia`
      ON ((`benificiaries`.`provincia`.`id` = `benificiaries`.`estudiante`.`provincisa`))) LEFT JOIN
    `benificiaries`.`unidadeducativa`
      ON ((`benificiaries`.`unidadeducativa`.`id` = `benificiaries`.`estudiante`.`unidadeducativa`))) LEFT JOIN
    `benificiaries`.`discapacidad`
      ON ((`benificiaries`.`discapacidad`.`id` = `benificiaries`.`estudiante`.`discapacidad`))) LEFT JOIN
    `benificiaries`.`tipodiscapacidad`
      ON ((`benificiaries`.`tipodiscapacidad`.`id` = `benificiaries`.`estudiante`.`tipodiscapacidad`))) LEFT JOIN
    `benificiaries`.`centros` ON ((`benificiaries`.`centros`.`id` = `benificiaries`.`estudiante`.`id_centro`))) JOIN
    `benificiaries`.`inscripcionestudiante`
      ON ((`benificiaries`.`inscripcionestudiante`.`id_estudiante` = `benificiaries`.`estudiante`.`id`))) JOIN
    `benificiaries`.`curso` ON ((`benificiaries`.`inscripcionestudiante`.`id_curso` = `benificiaries`.`curso`.`id`)))
  GROUP BY `benificiaries`.`estudiante`.`id`, `benificiaries`.`estudiante`.`nombres`,
    `benificiaries`.`estudiante`.`apellidopaterno`, `benificiaries`.`estudiante`.`apellidomaterno`,
    `benificiaries`.`estudiante`.`codigorude_es`, `benificiaries`.`estudiante`.`ci`, `benificiaries`.`curso`.`curso`,
    `benificiaries`.`discapacidad`.`nombre`, `benificiaries`.`tipodiscapacidad`.`nombre`,
    `benificiaries`.`unidadeducativa`.`nombre`, `benificiaries`.`inscripcionestudiante`.`fecha`,
    `benificiaries`.`estudiante`.`curso`, `benificiaries`.`estudiante`.`codigorude`;
