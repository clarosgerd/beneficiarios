CREATE VIEW viewestudiantecurso AS
  SELECT
    `benificiaries`.`unidadeducativa`.`nombre`                                     AS `unidadeducativa`,
    `benificiaries`.`departamento`.`nombre`                                        AS `departamento`,
    `benificiaries`.`provincia`.`nombre`                                           AS `provincia`,
    `benificiaries`.`municipio`.`descripcion`                                      AS `municipio`,
    `benificiaries`.`estudiante`.`codigorude_es`                                   AS `codigorude_es`,
    `benificiaries`.`estudiante`.`nombres`                                         AS `nombre`,
    `benificiaries`.`estudiante`.`apellidomaterno`                                 AS `materno`,
    `benificiaries`.`estudiante`.`apellidopaterno`                                 AS `paterno`,
    `benificiaries`.`estudiante`.`nrodiscapacidad`                                 AS `nrodiscapacidad`,
    `benificiaries`.`estudiante`.`ci`                                              AS `ci`,
    `benificiaries`.`estudiante`.`fechanacimiento`                                 AS `fechanacimiento`,
    timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) AS `edad`,
    `benificiaries`.`estudiante`.`sexo`                                            AS `sexo`,
    `benificiaries`.`discapacidad`.`nombre`                                        AS `discapacidad`,
    `benificiaries`.`tipodiscapacidad`.`nombre`                                    AS `tipodiscapcidad`,
    `benificiaries`.`centros`.`nombreinstitucion`                                  AS `centro`,
    `benificiaries`.`curso`.`curso`                                                AS `curso`,
    `benificiaries`.`inscripcionestudiante`.`fecha`                                AS `fecha`
  FROM (((((((((`benificiaries`.`estudiante`
    LEFT JOIN `benificiaries`.`departamento`
      ON ((`benificiaries`.`departamento`.`id` = `benificiaries`.`estudiante`.`departamento`))) LEFT JOIN
    `benificiaries`.`municipio`
      ON ((`benificiaries`.`municipio`.`id` = `benificiaries`.`estudiante`.`municipio`))) LEFT JOIN
    `benificiaries`.`provincia`
      ON ((`benificiaries`.`provincia`.`id` = `benificiaries`.`estudiante`.`provincisa`))) LEFT JOIN
    `benificiaries`.`unidadeducativa`
      ON ((`benificiaries`.`unidadeducativa`.`id` = `benificiaries`.`estudiante`.`unidadeducativa`))) LEFT JOIN
    `benificiaries`.`discapacidad`
      ON ((`benificiaries`.`discapacidad`.`id` = `benificiaries`.`estudiante`.`discapacidad`))) LEFT JOIN
    `benificiaries`.`tipodiscapacidad`
      ON ((`benificiaries`.`tipodiscapacidad`.`id` = `benificiaries`.`estudiante`.`tipodiscapacidad`))) LEFT JOIN
    `benificiaries`.`centros` ON ((`benificiaries`.`centros`.`id` = `benificiaries`.`estudiante`.`id_centro`))) JOIN
    `benificiaries`.`inscripcionestudiante`
      ON ((`benificiaries`.`inscripcionestudiante`.`id_estudiante` = `benificiaries`.`estudiante`.`id`))) JOIN
    `benificiaries`.`curso` ON ((`benificiaries`.`inscripcionestudiante`.`id_curso` = `benificiaries`.`curso`.`id`)));
