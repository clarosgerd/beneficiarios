CREATE VIEW viewparticipante AS
  SELECT
    `benificiaries`.`sector`.`nombre`                   AS `sector`,
    `benificiaries`.`actividad`.`nombreactividad`       AS `actividad`,
    `benificiaries`.`categoria`.`nombre`                AS `categoria`,
    `benificiaries`.`centros`.`nombreinstitucion`       AS `nombreinstitucion`,
    `benificiaries`.`participante`.`nombre`             AS `nombre`,
    `benificiaries`.`participante`.`apellidopaterno`    AS `apellidopaterno`,
    `benificiaries`.`participante`.`apellidomaterno`    AS `apellidomaterno`,
    `benificiaries`.`participante`.`fecha_nacimiento`   AS `fecha_nacimiento`,
    `benificiaries`.`participante`.`sexo`               AS `sexo`,
    `benificiaries`.`participante`.`ci`                 AS `ci`,
    `benificiaries`.`participante`.`nrodiscapacidad`    AS `nrodiscapacidad`,
    `benificiaries`.`participante`.`celular`            AS `celular`,
    `benificiaries`.`participante`.`direcciondomicilio` AS `direcciondomicilio`,
    `benificiaries`.`participante`.`ocupacion`          AS `ocupacion`,
    `benificiaries`.`participante`.`email`              AS `email`,
    `benificiaries`.`participante`.`cargo`              AS `cargo`,
    `benificiaries`.`participante`.`nivelestudio`       AS `nivelestudio`,
    `benificiaries`.`participante`.`observaciones`      AS `observaciones`
  FROM ((((`benificiaries`.`participante`
    LEFT JOIN `benificiaries`.`sector`
      ON ((`benificiaries`.`sector`.`id` = `benificiaries`.`participante`.`id_sector`))) LEFT JOIN
    `benificiaries`.`actividad`
      ON ((`benificiaries`.`actividad`.`id` = `benificiaries`.`participante`.`id_actividad`))) LEFT JOIN
    `benificiaries`.`categoria`
      ON ((`benificiaries`.`categoria`.`id` = `benificiaries`.`participante`.`id_categoria`))) LEFT JOIN
    `benificiaries`.`centros` ON ((`benificiaries`.`centros`.`id` = `benificiaries`.`participante`.`id_centro`)));
