CREATE VIEW viewmarcologicosummary AS
  SELECT
    `viewmarcologico`.`nombreinstitucion` AS `nombreinstitucion`,
    `viewmarcologico`.`fecha`             AS `fecha`,
    sum((CASE WHEN (`viewmarcologico`.`cuadro1` > 0)
      THEN 1
         ELSE 0 END))                     AS `cuadro1`,
    sum((CASE WHEN (`viewmarcologico`.`cuadro2` > 0)
      THEN 1
         ELSE 0 END))                     AS `cuadro2`,
    sum((CASE WHEN (`viewmarcologico`.`cuadro3` > 0)
      THEN 1
         ELSE 0 END))                     AS `cuadro3`,
    sum((CASE WHEN (`viewmarcologico`.`cuadro4` > 0)
      THEN 1
         ELSE 0 END))                     AS `cuadro4`,
    sum((CASE WHEN (`viewmarcologico`.`cuadro5` > 0)
      THEN 1
         ELSE 0 END))                     AS `cuadro5`,
    sum((CASE WHEN (`viewmarcologico`.`cuadro6` > 0)
      THEN 1
         ELSE 0 END))                     AS `cuadro6`,
    sum((CASE WHEN (`viewmarcologico`.`cuadro7` > 0)
      THEN 1
         ELSE 0 END))                     AS `cuadro7`,
    sum((CASE WHEN (`viewmarcologico`.`cuadro8` > 0)
      THEN 1
         ELSE 0 END))                     AS `cuadro8`,
    sum((CASE WHEN (`viewmarcologico`.`cuadro9` > 0)
      THEN 1
         ELSE 0 END))                     AS `cuadro9`,
    sum((CASE WHEN (`viewmarcologico`.`cuadro10` > 0)
      THEN 1
         ELSE 0 END))                     AS `cuadro10`
  FROM `benificiaries`.`viewmarcologico`
  GROUP BY `viewmarcologico`.`nombreinstitucion`, `viewmarcologico`.`fecha`;
