CREATE VIEW viewmarcologico AS
  SELECT
    `benificiaries`.`centros`.`nombreinstitucion`   AS `nombreinstitucion`,
    `benificiaries`.`inscripcionestudiante`.`fecha` AS `fecha`,
    `benificiaries`.`estudiante`.`id`               AS `cuadro1`,
    0                                               AS `cuadro2`,
    0                                               AS `cuadro3`,
    0                                               AS `cuadro4`,
    0                                               AS `cuadro5`,
    0                                               AS `cuadro6`,
    0                                               AS `cuadro7`,
    0                                               AS `cuadro8`,
    0                                               AS `cuadro9`,
    0                                               AS `cuadro10`
  FROM (((`benificiaries`.`estudiante`
    JOIN `benificiaries`.`centros`
      ON ((`benificiaries`.`centros`.`id` = `benificiaries`.`estudiante`.`id_centro`))) JOIN
    `benificiaries`.`inscripcionestudiante`
      ON ((`benificiaries`.`inscripcionestudiante`.`id_estudiante` = `benificiaries`.`estudiante`.`id`))) JOIN
    `benificiaries`.`curso` ON ((`benificiaries`.`inscripcionestudiante`.`id_curso` = `benificiaries`.`curso`.`id`)))
  WHERE (timestampdiff(YEAR, `benificiaries`.`estudiante`.`fechanacimiento`, curdate()) IN (0, 1, 2, 3, 4))
  UNION ALL SELECT
              `benificiaries`.`centros`.`nombreinstitucion`   AS `nombreinstitucion`,
              `benificiaries`.`inscripcionestudiante`.`fecha` AS `fecha`,
              0                                               AS `cuadro1`,
              `benificiaries`.`estudiante`.`id`               AS `cuadro2`,
              0                                               AS `cuadro3`,
              0                                               AS `cuadro4`,
              0                                               AS `cuadro5`,
              0                                               AS `cuadro6`,
              0                                               AS `cuadro7`,
              0                                               AS `cuadro8`,
              0                                               AS `cuadro9`,
              0                                               AS `cuadro10`
            FROM (((`benificiaries`.`estudiante`
              JOIN `benificiaries`.`centros`
                ON ((`benificiaries`.`centros`.`id` = `benificiaries`.`estudiante`.`id_centro`))) JOIN
              `benificiaries`.`inscripcionestudiante`
                ON ((`benificiaries`.`inscripcionestudiante`.`id_estudiante` = `benificiaries`.`estudiante`.`id`))) JOIN
              `benificiaries`.`curso`
                ON ((`benificiaries`.`inscripcionestudiante`.`id_curso` = `benificiaries`.`curso`.`id`)))
            WHERE (`benificiaries`.`estudiante`.`discapacidad` = 1)
  UNION ALL SELECT
              `benificiaries`.`centros`.`nombreinstitucion` AS `nombreinstitucion`,
              `benificiaries`.`actividad`.`fecha_fin`       AS `fecha`,
              0                                             AS `cuadro1`,
              0                                             AS `cuadro2`,
              `benificiaries`.`participante`.`id`           AS `cuadro3`,
              0                                             AS `cuadro4`,
              0                                             AS `cuadro5`,
              0                                             AS `cuadro6`,
              0                                             AS `cuadro7`,
              0                                             AS `cuadro8`,
              0                                             AS `cuadro9`,
              0                                             AS `cuadro10`
            FROM ((`benificiaries`.`actividad`
              JOIN `benificiaries`.`participante`
                ON ((`benificiaries`.`actividad`.`id` = `benificiaries`.`participante`.`id_actividad`))) JOIN
              `benificiaries`.`centros`
                ON ((`benificiaries`.`centros`.`id` = `benificiaries`.`participante`.`id_centro`)))
            WHERE (`benificiaries`.`participante`.`id_categoria` = 13)
  UNION ALL SELECT
              `benificiaries`.`centros`.`nombreinstitucion` AS `nombreinstitucion`,
              `benificiaries`.`actividad`.`fecha_fin`       AS `fecha`,
              0                                             AS `cuadro1`,
              0                                             AS `cuadro2`,
              0                                             AS `cuadro3`,
              `benificiaries`.`participante`.`id`           AS `cuadro4`,
              0                                             AS `cuadro5`,
              0                                             AS `cuadro6`,
              0                                             AS `cuadro7`,
              0                                             AS `cuadro8`,
              0                                             AS `cuadro9`,
              0                                             AS `cuadro10`
            FROM ((`benificiaries`.`actividad`
              JOIN `benificiaries`.`participante`
                ON ((`benificiaries`.`actividad`.`id` = `benificiaries`.`participante`.`id_actividad`))) JOIN
              `benificiaries`.`centros`
                ON ((`benificiaries`.`centros`.`id` = `benificiaries`.`participante`.`id_centro`)))
            WHERE (`benificiaries`.`participante`.`id_categoria` = 5)
  UNION ALL SELECT
              `benificiaries`.`centros`.`nombreinstitucion` AS `nombreinstitucion`,
              `benificiaries`.`actividad`.`fecha_fin`       AS `fecha`,
              0                                             AS `cuadro1`,
              0                                             AS `cuadro2`,
              0                                             AS `cuadro3`,
              0                                             AS `cuadro4`,
              `benificiaries`.`participante`.`id`           AS `cuadro5`,
              0                                             AS `cuadro6`,
              0                                             AS `cuadro7`,
              0                                             AS `cuadro8`,
              0                                             AS `cuadro9`,
              0                                             AS `cuadro10`
            FROM ((`benificiaries`.`actividad`
              JOIN `benificiaries`.`participante`
                ON ((`benificiaries`.`actividad`.`id` = `benificiaries`.`participante`.`id_actividad`))) JOIN
              `benificiaries`.`centros`
                ON ((`benificiaries`.`centros`.`id` = `benificiaries`.`participante`.`id_centro`)))
            WHERE (`benificiaries`.`participante`.`id_categoria` = 5)
  UNION ALL SELECT
              `benificiaries`.`centros`.`nombreinstitucion` AS `nombreinstitucion`,
              `benificiaries`.`actividad`.`fecha_fin`       AS `fecha`,
              0                                             AS `cuadro1`,
              0                                             AS `cuadro2`,
              0                                             AS `cuadro3`,
              0                                             AS `cuadro4`,
              0                                             AS `cuadro5`,
              `benificiaries`.`participante`.`id`           AS `cuadro6`,
              0                                             AS `cuadro7`,
              0                                             AS `cuadro8`,
              0                                             AS `cuadro9`,
              0                                             AS `cuadro10`
            FROM ((`benificiaries`.`actividad`
              JOIN `benificiaries`.`participante`
                ON ((`benificiaries`.`actividad`.`id` = `benificiaries`.`participante`.`id_actividad`))) JOIN
              `benificiaries`.`centros`
                ON ((`benificiaries`.`centros`.`id` = `benificiaries`.`participante`.`id_centro`)))
            WHERE (`benificiaries`.`participante`.`id_categoria` = 5)
  UNION ALL SELECT
              `benificiaries`.`centros`.`nombreinstitucion`   AS `nombreinstitucion`,
              `benificiaries`.`inscripcionestudiante`.`fecha` AS `fecha`,
              0                                               AS `cuadro1`,
              0                                               AS `cuadro2`,
              0                                               AS `cuadro3`,
              0                                               AS `cuadro4`,
              0                                               AS `cuadro5`,
              0                                               AS `cuadro6`,
              `benificiaries`.`estudiante`.`id`               AS `cuadro7`,
              0                                               AS `cuadro8`,
              0                                               AS `cuadro9`,
              0                                               AS `cuadro10`
            FROM (((`benificiaries`.`estudiante`
              JOIN `benificiaries`.`centros`
                ON ((`benificiaries`.`centros`.`id` = `benificiaries`.`estudiante`.`id_centro`))) JOIN
              `benificiaries`.`inscripcionestudiante`
                ON ((`benificiaries`.`inscripcionestudiante`.`id_estudiante` = `benificiaries`.`estudiante`.`id`))) JOIN
              `benificiaries`.`curso`
                ON ((`benificiaries`.`inscripcionestudiante`.`id_curso` = `benificiaries`.`curso`.`id`)))
            WHERE (`benificiaries`.`estudiante`.`discapacidad` = 1)
  UNION ALL SELECT
              `benificiaries`.`centros`.`nombreinstitucion` AS `nombreinstitucion`,
              `benificiaries`.`actividad`.`fecha_fin`       AS `fecha`,
              0                                             AS `cuadro1`,
              0                                             AS `cuadro2`,
              0                                             AS `cuadro3`,
              0                                             AS `cuadro4`,
              0                                             AS `cuadro5`,
              0                                             AS `cuadro6`,
              0                                             AS `cuadro7`,
              `benificiaries`.`participante`.`id`           AS `cuadro8`,
              0                                             AS `cuadro9`,
              0                                             AS `cuadro10`
            FROM ((`benificiaries`.`actividad`
              JOIN `benificiaries`.`participante`
                ON ((`benificiaries`.`actividad`.`id` = `benificiaries`.`participante`.`id_actividad`))) JOIN
              `benificiaries`.`centros`
                ON ((`benificiaries`.`centros`.`id` = `benificiaries`.`participante`.`id_centro`)))
            WHERE (`benificiaries`.`participante`.`id_categoria` = 11)
  UNION ALL SELECT
              `benificiaries`.`centros`.`nombreinstitucion` AS `nombreinstitucion`,
              `benificiaries`.`actividad`.`fecha_fin`       AS `fecha`,
              0                                             AS `cuadro1`,
              0                                             AS `cuadro2`,
              0                                             AS `cuadro3`,
              0                                             AS `cuadro4`,
              0                                             AS `cuadro5`,
              0                                             AS `cuadro6`,
              0                                             AS `cuadro7`,
              0                                             AS `cuadro8`,
              `benificiaries`.`participante`.`id`           AS `cuadro9`,
              0                                             AS `cuadro10`
            FROM ((`benificiaries`.`actividad`
              JOIN `benificiaries`.`participante`
                ON ((`benificiaries`.`actividad`.`id` = `benificiaries`.`participante`.`id_actividad`))) JOIN
              `benificiaries`.`centros`
                ON ((`benificiaries`.`centros`.`id` = `benificiaries`.`participante`.`id_centro`)))
            WHERE (`benificiaries`.`participante`.`id_categoria` = 8)
  UNION ALL SELECT
              `benificiaries`.`centros`.`nombreinstitucion` AS `nombreinstitucion`,
              `benificiaries`.`actividad`.`fecha_fin`       AS `fecha`,
              0                                             AS `cuadro1`,
              0                                             AS `cuadro2`,
              0                                             AS `cuadro3`,
              0                                             AS `cuadro4`,
              0                                             AS `cuadro5`,
              0                                             AS `cuadro6`,
              0                                             AS `cuadro7`,
              0                                             AS `cuadro8`,
              0                                             AS `cuadro9`,
              `benificiaries`.`participante`.`id`           AS `cuadro10`
            FROM ((`benificiaries`.`actividad`
              JOIN `benificiaries`.`participante`
                ON ((`benificiaries`.`actividad`.`id` = `benificiaries`.`participante`.`id_actividad`))) JOIN
              `benificiaries`.`centros`
                ON ((`benificiaries`.`centros`.`id` = `benificiaries`.`participante`.`id_centro`)))
            WHERE (`benificiaries`.`participante`.`id_sector` = 6);
